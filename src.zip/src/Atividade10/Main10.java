package Atividade10;

public class Main10 {
    public static void main(String[] args) {


        Funcionario func01 = new Funcionario("Evandro",36,8250.00);

        func01.imprimirDados();
        func01.toString();

        System.out.println("atividade10");


    }
}
