package Atividade09;

public class Imovel {

    protected double valorImovel;


    public Imovel() {
    }

    public Imovel(double valorImovel) {
        this.valorImovel = valorImovel;
    }

    public double calcularValor(){
        return valorImovel;
    }
}
