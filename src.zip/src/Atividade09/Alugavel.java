package Atividade09;

public interface Alugavel {

    public double calcularValorAluguel();
}
